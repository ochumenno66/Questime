<?php
/*
Template Name: About Us
*/

get_header();

// Hero — данные из ACF
$au_bg         = get_field('au_hero_bg')        ?: '';
$au_title      = get_field('au_hero_title')     ?: 'About our team';
$au_text       = get_field('au_hero_text')      ?: 'We believe that the greatest happiness is the happiness of communication and smart entertainment.';
$au_image      = get_field('au_hero_image')     ?: get_template_directory_uri() . '/assets/images/about-us/about-us-hero.png';
$au_image_alt  = get_field('au_hero_image_alt') ?: 'About us hero';
$au_btn1_text  = get_field('au_hero_btn_1_text') ?: 'Request';
$au_btn2_text  = get_field('au_hero_btn_2_text') ?: 'Download the presentation';
$au_pdf        = get_field('au_hero_pdf')        ?: '';

$au_bg_style = $au_bg
  ? ' style="background: linear-gradient(0deg, rgba(25, 26, 24, 0.7), rgba(25, 26, 24, 0.7)), linear-gradient(180deg, #191a18 0%, rgba(25, 26, 24, 0) 49.04%, #191a18 100%), url(\'' . esc_url($au_bg) . '\') center / cover no-repeat;"'
  : '';

// Stats — данные из ACF
// Карточка 1
$s1_icon   = get_field('au_stats_1_icon') ?: get_template_directory_uri() . '/assets/icons/person-black-EP-AU.svg';
$s1_number = get_field('au_stats_1_number') ?: '400 000 people';
$s1_text   = get_field('au_stats_1_text') ?: 'played with us';

// Карточка 2
$s2_icon   = get_field('au_stats_2_icon') ?: get_template_directory_uri() . '/assets/icons/date-EP-AU.svg';
$s2_number = get_field('au_stats_2_number') ?: '13 years';
$s2_text   = get_field('au_stats_2_text') ?: 'experience';

// Карточка 3
$s3_icon   = get_field('au_stats_3_icon') ?: get_template_directory_uri() . '/assets/icons/format-black-EP-AU.svg';
$s3_number = get_field('au_stats_3_number') ?: '10 000 events';
$s3_text   = get_field('au_stats_3_text') ?: 'for groups 6 – 800 people';
?>

<main>
  <!-- Секция Hero -->
  <section class="aboutus-hero hero section-special section-decorated-dark" id="hero">
    <div class="aboutus-hero__bg" <?php echo $au_bg_style; ?>></div>

    <div class="aboutus-hero__wrapper container">
      <!-- Хлебные крошки — автоматические -->
      <?php questime_breadcrumbs(); ?>
      <div class="custom-games-hero__content">
        <h1 class="custom-games-hero__title"><?php echo esc_html($au_title); ?></h1>
        <div class="aboutus-hero__image-wrap--mobile">
          <img
            src="<?php echo esc_url($au_image); ?>"
            alt="<?php echo esc_attr($au_image_alt); ?>"
            class="aboutus-hero__image" />
        </div>
        <div class="aboutus-hero__body">

          <p><?php echo wp_kses_post($au_text); ?></p>
        </div>

        <div class="aboutus-hero__actions">
          <button
            type="button"
            class="btn btn-secondary btn--orange"
            data-modal="request">
            <?php echo esc_html($au_btn1_text); ?>
          </button>
          <?php if ($au_pdf) : ?>
            <a
              href="<?php echo esc_url($au_pdf); ?>"
              download
              class="btn btn-secondary btn-download btn--transparent">
              <?php echo esc_html($au_btn2_text); ?>
            </a>
          <?php endif; ?>
        </div>
      </div>

      <div class="aboutus-hero__image-wrap">
        <img
          src="<?php echo esc_url($au_image); ?>"
          alt="<?php echo esc_attr($au_image_alt); ?>"
          class="aboutus-hero__image" />
      </div>
    </div>
  </section>
  <!-- Секция Stats -->
  <section class="stats-au section-special" id="stats-au">
    <div class="stats-au__wrapper container">
      <div class="stats-au__item">
        <div class="stats-au__card">
          <img class="stats-au__icon" src="<?php echo esc_url($s1_icon); ?>" alt="<?php echo esc_attr($s1_number); ?>">
          <p class="stats-au__number">
            <?php echo esc_html($s1_number); ?>
          </p>
          <p class="stats-au__text">
            <?php echo esc_html($s1_text); ?>
          </p>
        </div>
      </div>
      <div class="stats-au__item">
        <div class="stats-au__card">
          <img class="stats-au__icon" src="<?php echo esc_url($s2_icon); ?>" alt="<?php echo esc_attr($s2_number); ?>">
          <p class="stats-au__number">
            <?php echo esc_html($s2_number); ?>
          </p>
          <p class="stats-au__text">
            <?php echo esc_html($s2_text); ?>
          </p>
        </div>
      </div>
      <div class="stats-au__item">
        <div class="stats-au__card">
          <img class="stats-au__icon" src="<?php echo esc_url($s3_icon); ?>" alt="<?php echo esc_attr($s3_number); ?>">
          <p class="stats-au__number">
            <?php echo esc_html($s3_number); ?>
          </p>
          <p class="stats-au__text">
            <?php echo esc_html($s3_text); ?>
          </p>
        </div>
      </div>
    </div>
  </section>
  <!-- Секция Experience -->
  <?php get_template_part('templates/experience-case-product'); ?>
  <!-- Секция Team -->
  <section class="team section-special" id="team">
    <?php if (get_field('team_heading')) : ?>
      <h2 class="team__title text-align">
        <?php the_field('team_heading'); ?>
      </h2>
    <?php endif; ?>
    <div class="team__list">

      <?php for ($i = 1; $i <= 4; $i++) :
        $photo = get_field("team_member_{$i}_photo");
        $name = get_field("team_member_{$i}_name");
        $bio = get_field("team_member_{$i}_bio");
        $years = get_field("team_member_{$i}_years");
        $plays = get_field("team_member_{$i}_plays");
        $projects = get_field("team_member_{$i}_projects");
        if (!$name) {
          continue;
        }
        $reverse_class = ($i % 2 === 0) ? 'team__member--reverse' : '';
      ?>

        <div class="team__member <?php echo $reverse_class; ?>">
          <div class="container">
            <div class="team__photo-wrap">
              <?php if ($photo) : ?>
                <img
                  class="team__photo"
                  src="<?php echo esc_url($photo['url']); ?>"
                  alt="<?php echo esc_attr($name); ?>">
              <?php endif; ?>
            </div>
            <div class="team__info">
              <h3 class="team__name">
                <?php echo esc_html($name); ?>
              </h3>
              <div class="team__bio-wrapper">
                <?php echo wp_kses_post($bio); ?>
              </div>
              <div class="team__stats">
                <?php if ($years) : ?>
                  <div class="team__stat">
                    <span class="team__stat-value">
                      <?php echo esc_html($years); ?>
                    </span>
                    <span class="team__stat-label">years</span>
                  </div>
                <?php endif; ?>
                <?php if ($plays) : ?>
                  <div class="team__stat">
                    <span class="team__stat-value">
                      <?php echo esc_html($plays); ?>
                    </span>
                    <span class="team__stat-label">plays</span>
                  </div>
                <?php endif; ?>
                <?php if ($projects) : ?>
                  <div class="team__stat">
                    <span class="team__stat-value">
                      <?php echo esc_html($projects); ?>
                    </span>
                    <span class="team__stat-label">projects</span>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      <?php endfor; ?>
    </div>
  </section>
  <!-- Секция Subscribe -->
  <?php
  $instagram = get_theme_mod('instagram_url', '#');
  $threads = get_theme_mod('threads_url', '#');
  $linkedin = get_theme_mod('linkedin_url', '#');
  ?>
  <section class="subscribe-about-us section-special decorated-light-stats decorated-dark-stats" id="subscribe-about-us" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/main/stats.webp');">
    <div class="subscribe-about-us__overlay"></div>
    <div class="container subscribe-about-us__container">
      <h2 class="subscribe-about-us__title">Join Us</h2>

      <div class="subscribe-about-us__socials">
        <a href="<?php echo esc_url($instagram); ?>" class="subscribe-about-us__link" target="_blank" rel="noopener noreferrer">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/about-us/instagram-rhomb.svg" alt="" class="subscribe-about-us__rhomb">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/logo_instagram.svg" alt="Instagram" class="subscribe-about-us__icon">
        </a>

        <a href="<?php echo esc_url($threads); ?>" class="subscribe-about-us__link" target="_blank" rel="noopener noreferrer">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/about-us/threads-rhomb.svg" alt="" class="subscribe-about-us__rhomb">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/logo_threads.svg" alt="Threads" class="subscribe-about-us__icon">
        </a>

        <a href="<?php echo esc_url($linkedin); ?>" class="subscribe-about-us__link" target="_blank" rel="noopener noreferrer">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/about-us/linkedin-rhomb.svg" alt="" class="subscribe-about-us__rhomb">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/icons/logo_linkedin.svg" alt="LinkedIn" class="subscribe-about-us__icon">
        </a>
      </div>
    </div>
  </section>
  <!-- Секция Benefits -->
  <?php get_template_part('templates/benefits'); ?>
  <!-- Секция CTA -->
  <?php get_template_part('templates/cta'); ?>
  <!-- Секция Form -->
  <section class="contact-form section-special" id="contact-form">
    <div class="container">
      <h2 class="contact-form__title">Let's talk!</h2>
      <form class="contact-form__wrapper" action="#" method="post">
        <div class="contact-form__content">
          <div class="contact-form__info">
            <p class="contact-form__text text-bottom">Feel free to ask your question or make a request directly. Nataly or Mark will contact you within one business day.</p>
            <p class="contact-form__text">Prefer to call? Please do!</p>
            <p class="contact-form__text">Our number is <a class="contact-form__phone" href="https://wa.me/31612365246" target="_blank">+31 6 123 65 246</a></p>
          </div>
        </div>
        <div class="contact-form__fields">
          <input class="contact-form__input" type="text" name="name" placeholder="Name" required>
          <input class="contact-form__input" type="tel" name="phone" placeholder="Phone number" required>
          <input class="contact-form__input" type="text" name="company" placeholder="Company" required>
          <input class="contact-form__input" type="email" name="email" placeholder="Email" required>
        </div>
        <textarea class="contact-form__textarea" name="message" placeholder="Text of your request" required></textarea>
        <div class="contact-form__actions">
          <button class="btn btn-secondary contact-form__btn btn--orange" type="submit">Answer me!</button>
          <div class="checkbox">
            <input type="checkbox" id="agree" required>
            <label for="agree">By subscribing, you agree to our <a href="/privacy-policy.html" target="_blank">Privacy Policy</a></label>
          </div>
        </div>
        <div class="contact-form__image-wrapper">
          <img class="contact-form__image" src="<?php echo get_template_directory_uri(); ?>/assets/images/main/contact.jpg" alt="Nataly and Mark">
        </div>
      </form>
    </div>
  </section>
</main>

<?php get_footer(); ?>