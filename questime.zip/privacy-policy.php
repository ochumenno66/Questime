<?php
/*
Template Name: Privacy Policy
*/
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Privacy Policy</title>

    <?php wp_head(); ?>
</head>
<body>
    <main class="privacy-policy__content container">
        <div class="privacy container">
            <div class="privacy-content">
                <h2 id="privacy-title">Privacy Policy</h2>
                <p><strong>Last updated:</strong> 08.09.2025</p>
                <p>Questime & WhatifTour B. V. (“we,” “our,” or “us”), based in the Netherlands, respects your privacy and is committed to protecting your personal information. This Privacy Policy explains how we collect, use, and protect your data when you interact with our website.</p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>1. Information We Collect</h3>
                <p>When you submit a request or inquiry through our website, we may collect the following personal information:</p>
                <ul>
                    <li>Name</li>
                    <li>Email address</li>
                    <li>Phone number</li>
                </ul>
                <p>We do not intentionally collect any other personal information.</p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>2. How We Use Your Information</h3>
                <p>We use the information you provide for the following purposes:</p>
                <ul>
                    <li>To respond to your inquiries and requests</li>
                    <li>To contact you regarding our services</li>
                    <li>To provide customer support and communication</li>
                </ul>
                <p>We will not use your personal information for purposes unrelated to the above without your consent.</p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>3. Legal Bases for Processing (GDPR)</h3>
                <p>As we are established in the Netherlands, we process personal data under the EU General Data Protection Regulation (GDPR). Our legal bases include:</p>
                <ul>
                    <li><strong>Consent:</strong> when you voluntarily submit your information via our website forms.</li>
                    <li><strong>Performance of a contract:</strong> when we use your information to provide requested services.</li>
                    <li><strong>Legitimate interests:</strong> such as responding to inquiries and improving communication.</li>
                </ul>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>4. Sharing of Information</h3>
                <p>We do not sell or trade your personal information.<br> We may disclose your information only:</p>
                <ul>
                    <li>To service providers who help us operate our website (bound by confidentiality agreements)</li>
                    <li>When required by law or legal process</li>
                </ul>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>5. Data Retention</h3>
                <p>We will retain your personal information only as long as necessary to fulfill the purposes outlined in this Privacy Policy or as required by law.</p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>6. Data Security</h3>
                <p>We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction.</p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>7. Your Rights (EEA & UK Users)</h3>
                <p>Under the GDPR, you have the following rights regarding your personal data:</p>
                <ul>
                    <li>The right to access the data we hold about you</li>
                    <li>The right to request correction of inaccurate data</li>
                    <li>The right to request deletion of your data</li>
                    <li>The right to restrict or object to processing</li>
                    <li>The right to data portability</li>
                </ul>
                <p>To exercise any of these rights, please contact us (see Section 9).</p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>8. Cookies and Tracking</h3>
                <p><strong>We use cookies!</strong></p>
                <p>
                    This website uses essential cookies to ensure its proper operation and tracking cookies to understand how you interact with it. The latter will be set only after consent.
                </p>
                <p>
                    Our website may use essential cookies for proper functionality. We do not use cookies for advertising or profiling. For more details, please see our <a href="#">Cookie Policy</a>.
                </p>
                <hr class="divider" role="separator" aria-hidden="true">
                <h3>9. Contact Us</h3>
                <p>If you have any questions about this Privacy Policy or your personal information, you can contact us at:</p>
                <p>Questime & WhatifTour B. V. <br>
                    2516CD, Zodiakplein 65, The Hague, Netherlands<br>
                    Email: <a href="mailto:founders.whatiftour@gmail.com">founders.whatiftour@gmail.com</a><br>
                    Phone: <a href="tel:+31612365246">+31 6 12365246</a> 
                </p>
                <p>If you are located in the European Economic Area (EEA), you also have the right to lodge a complaint with your local Data Protection Authority.</p>
            </div>
        </div>
    </main>

<?php wp_footer(); ?>